# 🚁 SkyFlock ROS2 Drone Simulation – Shivam Kushwaha

## 🎯 Objective
Simulate a drone flying a square mission using ROS 2 + PX4 offboard mode as part of the SkyFlock Technical Internship assignment.

## ✅ Implemented Mission
- Arm and takeoff
- Fly 4 waypoints forming a square
- Return to origin and land

## 📂 Files Included
- `missions/drone_mission.py`: Main ROS 2 mission node
- `launch/drone_mission.launch.py`: Launch file
- `README.md`: Documentation

## 🧠 Summary of What Changed
- Added a clean ROS 2 mission node without modifying existing repo structure
- Preserved the code style and added mission logic as a new script

## 🧪 How to Run
```bash
cd ~/swarm_drone
colcon build
source install/setup.bash
ros2 launch swarm_drone drone_mission.launch.py
```

## 🎥 Demo
> (Add your screen recording in `/demo` folder and link it here)

## 🌐 External Sources Used
- PX4 Offboard Docs: https://docs.px4.io/main/en/ros/ros2_offboard_control.html
- MAVROS Package Info: https://github.com/mavlink/mavros
- ChatGPT: Assisted in building structure and timing logic

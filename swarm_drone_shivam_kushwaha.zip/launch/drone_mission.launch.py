from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='swarm_drone',
            executable='drone_mission',
            name='drone_mission_node',
            output='screen',
            emulate_tty=True
        )
    ])

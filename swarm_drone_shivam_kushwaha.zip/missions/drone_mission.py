import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from mavros_msgs.msg import State
from mavros_msgs.srv import CommandBool, SetMode

class DroneMission(Node):
    def __init__(self):
        super().__init__('drone_mission_node')
        self.local_pos_pub = self.create_publisher(PoseStamped, '/mavros/setpoint_position/local', 10)
        self.state_sub = self.create_subscription(State, '/mavros/state', self.state_callback, 10)
        self.arming_client = self.create_client(CommandBool, '/mavros/cmd/arming')
        self.set_mode_client = self.create_client(SetMode, '/mavros/set_mode')

        self.state = State()
        self.timer = self.create_timer(0.1, self.timer_callback)

        self.waypoints = [
            (0.0, 0.0, 3.0),
            (5.0, 0.0, 3.0),
            (5.0, 5.0, 3.0),
            (0.0, 5.0, 3.0),
            (0.0, 0.0, 3.0),
            (0.0, 0.0, 0.0)
        ]
        self.current_wp = 0
        self.start_time = self.get_clock().now()

    def state_callback(self, msg):
        self.state = msg

    def timer_callback(self):
        pose = PoseStamped()
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x, pose.pose.position.y, pose.pose.position.z = self.waypoints[self.current_wp]
        self.local_pos_pub.publish(pose)

        if not self.state.armed:
            arm_req = CommandBool.Request()
            arm_req.value = True
            self.arming_client.call_async(arm_req)
        elif self.state.mode != 'OFFBOARD':
            mode_req = SetMode.Request()
            mode_req.custom_mode = 'OFFBOARD'
            self.set_mode_client.call_async(mode_req)

        elapsed = (self.get_clock().now() - self.start_time).nanoseconds / 1e9
        if elapsed > 5.0 and self.current_wp < len(self.waypoints) - 1:
            self.current_wp += 1
            self.start_time = self.get_clock().now()

def main(args=None):
    rclpy.init(args=args)
    node = DroneMission()
    rclpy.spin(node)
    rclpy.shutdown()

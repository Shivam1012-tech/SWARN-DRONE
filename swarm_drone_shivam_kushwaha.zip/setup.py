from setuptools import setup

package_name = 'swarm_drone'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Shivam Kushwaha',
    maintainer_email='shivam@example.com',
    description='ROS 2 PX4 drone mission for SkyFlock internship',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'drone_mission = missions.drone_mission:main'
        ],
    },
)
